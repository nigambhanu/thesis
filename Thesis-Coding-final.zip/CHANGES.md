# Changes in this version

Root causes found from the Colab run output, and what was changed.

| File | Change | Why |
|---|---|---|
| `evaluation/run_ablation.py` (RQ2) | `retriever.retrieve(...)` -> `retriever.retrieve_for_profile(...)` | RQ2 used plain top-4 retrieval, so recall was 4/25 = 0.160 regardless of quality. It now measures the retrieval the system actually uses. |
| `evaluation/run_ablation.py` (A3) | Removes `ANTI_HALLUCINATION_CLAUSE` (exact text, asserted) | The old replace string never matched the prompt (`do NOT` vs `DO NOT`), so prompt-on and prompt-off were identical. |
| `evaluation/run_ablation.py` (A6) | Reworded/normal profile text is now what the LLM sees (real LLM only) | `profile_text` was never used, so A6 compared identical inputs. |
| `evaluation/run_ablation.py` | `--limit N` (evenly spaced subsample), tqdm progress bar, `profile_text` loaded in `GoldRecord` | Full run is hours on a T4; makes staged runs possible. |
| `src/model.py` | New `SYSTEM_PROMPT` (explicit all-criteria procedure, lakh conversion, reason before verdict); `annual_income_in_lakh` line in profile block | The 3B model rejected eligible cards (recall 0.167); rules are written in words ("six lakh") while the profile is in rupees. |
| `src/model.py` | `parse_llm_response` skips malformed items, handles `null` reason / string booleans | One bad item used to discard all 8 decisions; `null` became the text "None". |
| `src/infrastructure/llm_client.py` | `max_new_tokens` 1536; persistent greedy-generation cache (`LLM_CACHE_PATH`, `LLM_CACHE=0` disables) | Identical prompts recur across arms (A1, RQ1, RQ4, A2 k>=4, A3-on, A5, A6). Cuts unique generations by ~3x and makes runs resumable after a disconnect. |
| `tests/test_fixes.py` | 6 regression tests | Parser, prompt, A3 clause, A6 builder, gold `profile_text`, cache. |

## Round 2 (after the 7B real-model run)

| File | Change | Why |
|---|---|---|
| `src/model.py` (`RAGRecommender`) | **Per-card prompting is now the default** (one short grounded prompt per card; `per_card=False` or `RAG_PER_CARD=0` restores the joint prompt) | Real 7B run: profile accuracy 0.175, per-card recall 0.365. The model mis-compared numbers (e.g. "age 30 is below 21") when judging 8 cards in one JSON answer. |
| `evaluation/run_ablation.py` | `--joint-prompt` flag | Lets you report joint vs per-card prompting as an extra comparison. |
| `tests/test_fixes.py` | per-card test (20 tests total) | Checks one prompt per card and that extra decisions are dropped. |

Note for the write-up: each card has only 3-4 rule chunks, so `top_k >= 4` retrieves identical context. A2 therefore only has power at k = 2 and 3.

## Round 3 (after the per-card run)

| File | Change | Why |
|---|---|---|
| `evaluation/run_ablation.py` (RQ4) | Now goes through `RAGRecommender` (per-card) | RQ4 still built one joint prompt, so its label-consistency (0.175) was the old joint accuracy, not the system's. |
| `evaluation/run_ablation.py` (A6) | Balanced sample of normal and reworded profiles (`a6_balanced_sample`) | Only 22 of 120 gold profiles are reworded; an evenly spaced subsample of 20 contained 1, so A6 was meaningless. |
| `tests/test_fixes.py` | 2 more tests (22 total) | A6 sampling; RQ4 issues one prompt per card. |

Prompts and retrieval were deliberately NOT changed in this round, so cached generations from the previous run are reused (re-running is fast except A6).

## Round 4: full audit (final version)

| Area | Finding | Fix |
|---|---|---|
| A1 / RQ3 (critical) | The ungrounded control prompt had its `### CARDS TO EVALUATE` list removed together with the rules, and still told the model to "use ONLY the retrieved rules". It could never be correct (0.0 accuracy in every run), so the McNemar significance was an artifact. | `strip_retrieved_rules` removes only the rules; new `UNGROUNDED_SYSTEM_PROMPT` (best-effort from general knowledge); `src/prompts.py` holds all prompt text. |
| Diagnostics | Parse failures/refusals silently counted as "wrong". | `cards_returned_rate` for grounded/ungrounded/RQ1; per-profile `predictions_*.jsonl`; per-card confusion counts; majority-class baseline. |
| Speed | 8 sequential generations per profile. | Per-card prompts are sent as one batched pipeline call (`LLM_BATCH_SIZE`, automatic sequential fallback on error); greedy generations cached on disk. |
| Mistral-style chat templates | A system role raises an error. | Falls back to a single user message. |
| A2 | k >= 4 identical (3-4 chunks per card). | Default sweep k = 1..4. |
| A4 | Hard-coded gated models. | `--a4-models` (default Qwen2.5-3B vs 7B). |
| RQ1 label | Said "RAGAS" although only gold accuracy is computed. | Relabelled. |
| Data | Truncated sentence in `hdfc_cards.md` ("already have a HDFC."). | Fixed. |
| Dependencies | `ragas` is never imported but caused langchain conflicts. | Removed; `tqdm` added. |
| Reproducibility | Results only printed. | `results/results.json` (merged across runs) with model, split, prompting mode and timings; `--split`; embedder-fallback guard. |
| Integrity | No automated check that docs, table, gold set and prompts agree. | `python -m evaluation.verify_setup` + tests (32 total). |
