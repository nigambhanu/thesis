# Results

*LLM:* `Qwen/Qwen2.5-7B-Instruct` | *embedding:* `sentence-transformers/all-MiniLM-L6-v2` | *per-card prompting:* True | *split:* dev | *profiles (core):* 40 | *run:* 2026-10-14T14:30:47+00:00

## A1 / RQ3: grounded vs ungrounded

| metric | value |
|---|---|
| profiles (n) | 40 |
| grounded profile accuracy | 0.225 |
| ungrounded profile accuracy | 0.000 |
| profiles fixed by grounding (b) | 9 |
| profiles broken by grounding (c) | 0 |
| McNemar p-value | 0.004 |
| relative error reduction | 0.225 |
| grounded cards returned | 1.000 |
| ungrounded cards returned | 0.675 |
| meets 0.90 stretch target | False |
| verdict | HYPOTHESIS SUPPORTED |

> Warning: the ungrounded arm returned fewer than 95% of the cards; part of its error may be output-format failure, not wrong knowledge.

## RQ1: gold-set classification (RAGAS faithfulness not computed)

| metric | value |
|---|---|
| precision | 0.794 |
| recall | 0.355 |
| f1 | 0.491 |
| accuracy | 0.825 |
| majority_class_accuracy | 0.762 |
| positive_rate_gold | 0.237 |
| positive_rate_predicted | 0.106 |
| cards_returned_rate | 1.000 |

## RQ2: retrieval (proxy relevance = all cards of requested banks; saturated, see EVALUATION_NOTES.md)

| metric | value |
|---|---|
| mean_context_precision | 1.000 |
| mean_context_recall | 1.000 |

## RQ4: explanation traceability

| metric | value |
|---|---|
| label_consistency_rate | 0.225 |
| citation_validity_rate | 0.991 |

### Error analysis (grounded arm)

| difficulty | profiles | profile accuracy |
|---|---|---|
| borderline | 20 | 0.200 |
| easy | 20 | 0.250 |

| card | tp | fp | fn | tn |
|---|---|---|---|---|
| HDFC Diners Club Black | 0 | 0 | 1 | 39 |
| HDFC Millennia | 2 | 1 | 8 | 29 |
| HDFC MoneyBack+ | 11 | 0 | 22 | 7 |
| HDFC Regalia | 0 | 0 | 5 | 35 |
| SBI Elite | 0 | 0 | 1 | 39 |
| SBI Prime | 0 | 1 | 5 | 34 |
| SBI SimplyCLICK | 1 | 0 | 2 | 37 |
| SBI SimplySAVE | 13 | 5 | 5 | 17 |


## Limitations

See `EVALUATION_NOTES.md` (synthetic oracle-derived gold set, borderline-heavy profiles, hedged documents, class imbalance, tiny corpus, small quantised model, RAGAS not computed).
