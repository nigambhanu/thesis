# Results

*LLM:* `Qwen/Qwen2.5-7B-Instruct` | *embedding:* `sentence-transformers/all-MiniLM-L6-v2` | *per-card prompting:* True | *split:* test | *profiles (core):* 40 | *run:* 2026-10-14T12:25:03+00:00

## A1 / RQ3: grounded vs ungrounded

| metric | value |
|---|---|
| profiles (n) | 40 |
| grounded profile accuracy | 0.400 |
| ungrounded profile accuracy | 0.000 |
| profiles fixed by grounding (b) | 16 |
| profiles broken by grounding (c) | 0 |
| McNemar p-value | 0.000 |
| relative error reduction | 0.400 |
| grounded cards returned | 1.000 |
| ungrounded cards returned | 0.719 |
| meets 0.90 stretch target | False |
| verdict | HYPOTHESIS SUPPORTED |

> Warning: the ungrounded arm returned fewer than 95% of the cards; part of its error may be output-format failure, not wrong knowledge.

## RQ1: gold-set classification (RAGAS faithfulness not computed)

| metric | value |
|---|---|
| precision | 0.953 |
| recall | 0.554 |
| f1 | 0.701 |
| accuracy | 0.891 |
| majority_class_accuracy | 0.769 |
| positive_rate_gold | 0.231 |
| positive_rate_predicted | 0.134 |
| cards_returned_rate | 1.000 |

## RQ2: retrieval (proxy relevance = all cards of requested banks; saturated, see EVALUATION_NOTES.md)

| metric | value |
|---|---|
| mean_context_precision | 1.000 |
| mean_context_recall | 1.000 |

## RQ4: explanation traceability

| metric | value |
|---|---|
| label_consistency_rate | 0.400 |
| citation_validity_rate | 0.988 |

## A2: rules kept per card (top-k) (core subset n=20)

| metric | value |
|---|---|
| 1 | 0.150 |
| 2 | 0.050 |
| 3 | 0.350 |
| 4 | 0.350 |

## A3: prompt pattern on/off (core subset n=20)

| metric | value |
|---|---|
| prompt_pattern_on_accuracy | 0.350 |
| prompt_pattern_off_accuracy | 0.750 |

## A4: model selection (core subset n=20)

| metric | value |
|---|---|
| Qwen/Qwen2.5-3B-Instruct | 0.050 |
| Qwen/Qwen2.5-7B-Instruct | 0.350 |

## A5: chunking granularity (core subset n=20)

| metric | value |
|---|---|
| fine_grained_1_rule_per_chunk_accuracy | 0.350 |
| coarse_multi_rule_per_chunk_accuracy | 0.850 |

## A6: normal vs reworded profiles (core subset n=40)

| metric | value |
|---|---|
| normal_accuracy | 0.350 |
| reworded_accuracy | 0.700 |
| normal_n | 20 |
| reworded_n | 20 |

### Error analysis (grounded arm)

| difficulty | profiles | profile accuracy |
|---|---|---|
| borderline | 20 | 0.350 |
| easy | 20 | 0.450 |

| card | tp | fp | fn | tn |
|---|---|---|---|---|
| HDFC Diners Club Black | 0 | 0 | 1 | 39 |
| HDFC Millennia | 3 | 0 | 6 | 31 |
| HDFC MoneyBack+ | 23 | 1 | 15 | 1 |
| HDFC Regalia | 1 | 0 | 3 | 36 |
| SBI Elite | 0 | 0 | 1 | 39 |
| SBI Prime | 1 | 0 | 2 | 37 |
| SBI SimplyCLICK | 0 | 0 | 4 | 36 |
| SBI SimplySAVE | 13 | 1 | 1 | 25 |


## Limitations

See `EVALUATION_NOTES.md` (synthetic oracle-derived gold set, borderline-heavy profiles, hedged documents, class imbalance, tiny corpus, small quantised model, RAGAS not computed).
